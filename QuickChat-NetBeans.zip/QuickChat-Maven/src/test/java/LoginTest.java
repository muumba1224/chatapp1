import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Part 1 - Registration and Login feature.
 * Uses the exact test data supplied in the PROG5121 PoE brief.
 */
public class LoginTest {

    private Login login;

    @BeforeEach
    void setUp() {
        login = new Login();
    }

    // ------------------------------------------------------------------
    // Username tests
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Username correctly formatted - contains underscore and <= 5 characters")
    void testUsernameCorrectlyFormatted() {
        // Test Data: "kyl_1"
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    @DisplayName("Username incorrectly formatted - no underscore / too long")
    void testUsernameIncorrectlyFormatted() {
        // Test Data: "kyle!!!!!!!"
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    // ------------------------------------------------------------------
    // Password tests
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Password meets complexity requirements")
    void testPasswordMeetsComplexity() {
        // Test Data: "Ch&&sec@ke99!"
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    @DisplayName("Password does not meet complexity requirements")
    void testPasswordDoesNotMeetComplexity() {
        // Test Data: "password"
        assertFalse(login.checkPasswordComplexity("password"));
    }

    // ------------------------------------------------------------------
    // Cell phone tests
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Cell phone number correctly formatted")
    void testCellPhoneCorrectlyFormatted() {
        // Test Data: +27838968976
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    @DisplayName("Cell phone number incorrectly formatted")
    void testCellPhoneIncorrectlyFormatted() {
        // Test Data: 08966553
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    // ------------------------------------------------------------------
    // Registration messaging tests (assertEquals)
    // ------------------------------------------------------------------

    @Test
    @DisplayName("registerUser - successful registration returns correct messages")
    void testRegisterUserSuccess() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");

        assertTrue(result.contains("Username successfully captured."));
        assertTrue(result.contains("Password successfully captured."));
        assertTrue(result.contains("Cell phone number successfully added."));
    }

    @Test
    @DisplayName("registerUser - bad username returns correct error")
    void testRegisterUserBadUsername() {
        String result = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals(
            "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
            result
        );
    }

    @Test
    @DisplayName("registerUser - bad password returns correct error")
    void testRegisterUserBadPassword() {
        String result = login.registerUser("kyl_1", "password", "+27838968976", "Kyle", "Smith");
        assertEquals(
            "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
            result
        );
    }

    // ------------------------------------------------------------------
    // Login tests (assertTrue / assertFalse)
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Login successful")
    void testLoginSuccessful() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    @DisplayName("Login failed")
    void testLoginFailed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertFalse(login.loginUser("wrong", "credentials"));
    }

    @Test
    @DisplayName("returnLoginStatus - successful login message")
    void testReturnLoginStatusSuccess() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        String status = login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!");
        assertEquals("Welcome Kyle, Smith it is great to see you again.", status);
    }

    @Test
    @DisplayName("returnLoginStatus - failed login message")
    void testReturnLoginStatusFailed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        String status = login.returnLoginStatus("wrong", "pass");
        assertEquals("Username or password incorrect, please try again.", status);
    }
}
