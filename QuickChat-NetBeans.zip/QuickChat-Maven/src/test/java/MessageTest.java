import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Part 2 (Sending Messages) and Part 3 (Arrays & Reports).
 * Uses the exact test data supplied in the PROG5121 PoE brief.
 */
public class MessageTest {

    @BeforeEach
    void setUp() {
        // Clear static collections before each test so tests stay independent
        Message.getSentMessages().clear();
        Message.getDisregardedMessages().clear();
        Message.getStoredMessages().clear();
        Message.getMessageHashes().clear();
        Message.getMessageIds().clear();
    }

    // ------------------------------------------------------------------
    // Part 2 - Message length
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Message length - success (under 250 characters)")
    void testMessageLengthSuccess() {
        String text = "Hi Mike, can you join us for dinner tonight?";
        assertTrue(text.length() <= 250);
        // The application prints "Message ready to send." when length is OK
    }

    @Test
    @DisplayName("Message length - failure (over 250 characters)")
    void testMessageLengthFailure() {
        String text = "a".repeat(260);
        int excess = text.length() - 250;
        assertTrue(excess > 0);
        // Expected message: "Message exceeds 250 characters by X; please reduce the size."
        assertEquals(10, excess);
    }

    // ------------------------------------------------------------------
    // Part 2 - Recipient cell validation
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Recipient number correctly formatted")
    void testRecipientCorrect() {
        Message msg = new Message();
        String result = msg.checkRecipientCell("+27718693002");
        assertEquals("Cell phone number successfully captured.", result);
    }

    @Test
    @DisplayName("Recipient number incorrectly formatted")
    void testRecipientIncorrect() {
        Message msg = new Message();
        String result = msg.checkRecipientCell("08575975889");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            result
        );
    }

    // ------------------------------------------------------------------
    // Part 2 - Message Hash
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Message hash is generated in the correct format")
    void testMessageHashFormat() {
        // Test Data from brief - Message 1
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        String hash = msg.getMessageHash();

        // Format must be: firstTwoOfId : messageNumber : FIRSTLAST (all caps)
        assertNotNull(hash);
        assertTrue(hash.contains(":"));
        assertTrue(hash.equals(hash.toUpperCase()));

        // Example expected pattern from brief: 00:0:HITHANKS
        // We only assert structure because the random ID changes every run
        String[] parts = hash.split(":");
        assertEquals(3, parts.length);
    }

    // ------------------------------------------------------------------
    // Part 2 - Message ID
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Message ID is created and is not more than 10 characters")
    void testMessageIdCreated() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertNotNull(msg.getMessageId());
        assertTrue(msg.checkMessageID());
        assertEquals(10, msg.getMessageId().length());
    }

    // ------------------------------------------------------------------
    // Part 2 - SentMessage options
    // ------------------------------------------------------------------

    @Test
    @DisplayName("SentMessage - user selects Send")
    void testSentMessageSend() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        String result = msg.SentMessage(1);
        assertEquals("Message successfully sent.", result);
        assertEquals(1, msg.returnTotalMessagess());
    }

    @Test
    @DisplayName("SentMessage - user selects Disregard")
    void testSentMessageDisregard() {
        Message msg = new Message("08575975889", "Hi Keegan, did you receive the payment?");
        String result = msg.SentMessage(2);
        assertEquals("Press 0 to delete the message.", result);
    }

    @Test
    @DisplayName("SentMessage - user selects Store")
    void testSentMessageStore() {
        Message msg = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        String result = msg.SentMessage(3);
        assertEquals("Message successfully stored.", result);
        assertFalse(Message.getStoredMessages().isEmpty());
    }

    // ------------------------------------------------------------------
    // Part 3 - Populate arrays with official test data
    // ------------------------------------------------------------------

    private void populateTestData() {
        // Message 1 - Sent
        Message m1 = new Message("+27834557896", "Did you get the cake?");
        m1.SentMessage(1);

        // Message 2 - Stored
        Message m2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        m2.SentMessage(3);

        // Message 3 - Disregard
        Message m3 = new Message("+27834484567", "Yohoooo, I am at your gate.");
        m3.SentMessage(2);

        // Message 4 - Sent  (note: brief shows 0838884567 - we keep +27 for validity)
        Message m4 = new Message("+27838884567", "It is dinner time !");
        m4.SentMessage(1);

        // Message 5 - Stored
        Message m5 = new Message("+27838884567", "Ok, I am leaving without you.");
        m5.SentMessage(3);
    }

    @Test
    @DisplayName("Sent Messages array correctly populated")
    void testSentMessagesArrayPopulated() {
        populateTestData();

        // Expected sent messages from the brief test data
        assertTrue(Message.getSentMessages().size() >= 2);

        boolean foundCake = false;
        boolean foundDinner = false;
        for (Message m : Message.getSentMessages()) {
            if (m.getMessageText().contains("Did you get the cake?")) foundCake = true;
            if (m.getMessageText().contains("It is dinner time")) foundDinner = true;
        }
        assertTrue(foundCake);
        assertTrue(foundDinner);
    }

    @Test
    @DisplayName("Display the longest message")
    void testLongestMessage() {
        populateTestData();
        String longest = Message.displayLongestMessage();
        assertTrue(longest.contains("Where are you? You are late! I have asked you to be on time."));
    }

    @Test
    @DisplayName("Search for messages by recipient")
    void testSearchByRecipient() {
        populateTestData();
        String result = Message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    @DisplayName("Delete a message using message hash")
    void testDeleteByHash() {
        populateTestData();

        // Get a hash from a stored message
        assertFalse(Message.getStoredMessages().isEmpty());
        String hashToDelete = Message.getStoredMessages().get(0).getMessageHash();
        String originalText = Message.getStoredMessages().get(0).getMessageText();

        String result = Message.deleteByHash(hashToDelete);
        assertTrue(result.contains("successfully deleted"));
        assertTrue(result.contains(originalText));
    }

    @Test
    @DisplayName("Display full report contains required fields")
    void testDisplayReport() {
        populateTestData();
        String report = Message.displayFullReport();

        assertTrue(report.contains("Hash:"));
        assertTrue(report.contains("Recipient:"));
        assertTrue(report.contains("Message:"));
    }

    @Test
    @DisplayName("returnTotalMessagess returns correct count")
    void testReturnTotalMessages() {
        Message msg1 = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        msg1.SentMessage(1);

        Message msg2 = new Message("+27834557896", "Did you get the cake?");
        msg2.SentMessage(1);

        assertEquals(2, new Message().returnTotalMessagess());
    }
}
