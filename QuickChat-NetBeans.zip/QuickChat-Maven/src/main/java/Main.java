import java.util.Scanner;

/**
 * QuickChat - Console Application
 * Implements Part 1 (Registration & Login), Part 2 (Sending Messages)
 * and Part 3 (Arrays, Search, Delete, Report).
 *
 * STRICTLY CONSOLE ONLY - no JOptionPane / Swing.
 */
public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final Login login = new Login();
    private static boolean loggedIn = false;

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("       WELCOME TO QUICKCHAT");
        System.out.println("========================================\n");

        // Registration + Login loop
        while (!loggedIn) {
            System.out.println("1) Register");
            System.out.println("2) Login");
            System.out.println("3) Exit");
            System.out.print("Choose an option: ");
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1" -> register();
                case "2" -> doLogin();
                case "3" -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid option. Please try again.\n");
            }
        }

        // Main application menu (only reachable after successful login)
        runMainMenu();
    }

    // ----------------------------------------------------------------
    // PART 1 - Registration
    // ----------------------------------------------------------------
    private static void register() {
        System.out.println("\n----- REGISTRATION -----");

        System.out.print("Enter first name: ");
        String firstName = sc.nextLine().trim();

        System.out.print("Enter last name: ");
        String lastName = sc.nextLine().trim();

        System.out.print("Enter username (must contain _ and be <= 5 characters): ");
        String username = sc.nextLine().trim();

        System.out.print("Enter password (>=8 chars, 1 capital, 1 number, 1 special): ");
        String password = sc.nextLine().trim();

        System.out.print("Enter South African cell number (+27xxxxxxxxx): ");
        String cell = sc.nextLine().trim();

        String result = login.registerUser(username, password, cell, firstName, lastName);
        System.out.println("\n" + result + "\n");
    }

    // ----------------------------------------------------------------
    // PART 1 - Login
    // ----------------------------------------------------------------
    private static void doLogin() {
        if (!login.isRegistered()) {
            System.out.println("No user registered yet. Please register first.\n");
            return;
        }

        System.out.println("\n----- LOGIN -----");
        System.out.print("Username: ");
        String username = sc.nextLine().trim();
        System.out.print("Password: ");
        String password = sc.nextLine().trim();

        String status = login.returnLoginStatus(username, password);
        System.out.println("\n" + status + "\n");

        if (login.loginUser(username, password)) {
            loggedIn = true;
        }
    }

    // ----------------------------------------------------------------
    // MAIN MENU (after successful login)
    // ----------------------------------------------------------------
    private static void runMainMenu() {
        System.out.println("Welcome to QuickChat.\n");

        while (true) {
            System.out.println("========== MAIN MENU ==========");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages (Coming Soon)");
            System.out.println("3) Stored Messages / Reports");
            System.out.println("4) Quit");
            System.out.print("Enter your choice: ");
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1" -> sendMessagesFlow();
                case "2" -> System.out.println("Coming Soon.\n");
                case "3" -> storedMessagesMenu();
                case "4" -> {
                    System.out.println("Thank you for using QuickChat. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid option. Please choose 1-4.\n");
            }
        }
    }

    // ----------------------------------------------------------------
    // PART 2 - Sending Messages
    // ----------------------------------------------------------------
    private static void sendMessagesFlow() {
        System.out.print("\nHow many messages do you wish to enter? ");
        int numMessages;
        try {
            numMessages = Integer.parseInt(sc.nextLine().trim());
            if (numMessages <= 0) {
                System.out.println("Please enter a positive number.\n");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid number.\n");
            return;
        }

        for (int i = 0; i < numMessages; i++) {
            System.out.println("\n----- Message " + (i + 1) + " of " + numMessages + " -----");

            // Recipient
            System.out.print("Enter recipient cell number (+27xxxxxxxxx): ");
            String recipient = sc.nextLine().trim();

            // Validate recipient using the required method
            Message validator = new Message();
            String cellResult = validator.checkRecipientCell(recipient);
            System.out.println(cellResult);
            if (!cellResult.startsWith("Cell phone number successfully")) {
                System.out.println("Please try again.\n");
                i--; // allow the user to re-enter this message
                continue;
            }

            // Message text
            System.out.print("Enter message (max 250 characters): ");
            String text = sc.nextLine();

            if (text.length() > 250) {
                System.out.println("Message exceeds 250 characters by " + (text.length() - 250) + "; please reduce the size.");
                i--;
                continue;
            }
            System.out.println("Message ready to send.");

            // Create the real message object
            Message message = new Message(recipient, text);

            // Show details
            System.out.println("\nMessage ID: " + message.getMessageId());
            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("Message: " + message.getMessageText());

            // Send / Store / Disregard
            System.out.println("\nWhat would you like to do with this message?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Choice: ");
            String action = sc.nextLine().trim();

            int actionChoice;
            try {
                actionChoice = Integer.parseInt(action);
            } catch (NumberFormatException e) {
                actionChoice = -1;
            }

            String result = message.SentMessage(actionChoice);
            System.out.println(result);
        }

        // After all messages
        Message summary = new Message();
        System.out.println("\nTotal messages sent: " + summary.returnTotalMessagess());
        System.out.println("\n----- Messages sent during this session -----");
        System.out.println(summary.printMessages());
    }

    // ----------------------------------------------------------------
    // PART 3 - Stored Messages menu
    // ----------------------------------------------------------------
    private static void storedMessagesMenu() {
        while (true) {
            System.out.println("\n===== STORED MESSAGES MENU =====");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest message");
            System.out.println("c) Search for a message ID");
            System.out.println("d) Search messages by recipient");
            System.out.println("e) Delete a message using the message hash");
            System.out.println("f) Display full report of all messages");
            System.out.println("g) Return to Main Menu");
            System.out.print("Enter choice: ");
            String choice = sc.nextLine().trim().toLowerCase();

            switch (choice) {
                case "a" -> System.out.println("\n" + Message.displaySendersAndRecipients());
                case "b" -> System.out.println("\nLongest message:\n" + Message.displayLongestMessage());
                case "c" -> {
                    System.out.print("Enter Message ID: ");
                    String id = sc.nextLine().trim();
                    System.out.println("\n" + Message.searchByMessageId(id));
                }
                case "d" -> {
                    System.out.print("Enter recipient number: ");
                    String rec = sc.nextLine().trim();
                    System.out.println("\n" + Message.searchByRecipient(rec));
                }
                case "e" -> {
                    System.out.print("Enter message hash to delete: ");
                    String hash = sc.nextLine().trim();
                    System.out.println("\n" + Message.deleteByHash(hash));
                }
                case "f" -> System.out.println("\n" + Message.displayFullReport());
                case "g" -> { return; }
                default  -> System.out.println("Invalid option.");
            }
        }
    }
}
