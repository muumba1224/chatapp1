import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Message class - Part 2 & Part 3 of the PoE
 * Contains all required methods plus array storage for the final report features.
 */
public class Message {

    // ---------- Instance fields ----------
    private String messageId;
    private int numMessagesSent;          // auto-incremented counter
    private String recipient;
    private String messageText;
    private String messageHash;
    private String flag;                   // "Sent", "Stored", "Disregard"

    // ---------- Static collections (Part 3 arrays) ----------
    private static final List<Message> sentMessages       = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();
    private static final List<Message> storedMessages      = new ArrayList<>();
    private static final List<String>  messageHashes       = new ArrayList<>();
    private static final List<String>  messageIds          = new ArrayList<>();

    private static int totalMessagesSent = 0;   // overall counter

    // ---------- Constructors ----------
    public Message() {
        // empty constructor for flexibility
    }

    public Message(String recipient, String messageText) {
        this.messageId = generateMessageId();
        this.numMessagesSent = ++totalMessagesSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    // ---------- Required methods from the brief ----------

    /**
     * Ensures the message ID is not more than ten characters.
     */
    public boolean checkMessageID() {
        return messageId != null && messageId.length() <= 10;
    }

    /**
     * Ensures recipient cell starts with an international code (+27)
     * and the number part is valid (matches the required test data format).
     */
    public String checkRecipientCell() {
        return checkRecipientCell(this.recipient);
    }

    /** Overloaded version so the method can be called before the object is fully created. */
    public String checkRecipientCell(String cell) {
        if (cell != null && cell.matches("^\\+27\\d{9}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    /**
     * Creates the Message Hash in the required format:
     * first two digits of Message ID : message number : FIRSTLAST (all caps)
     * Example: 00:0:HITHANKS
     */
    public String createMessageHash() {
        if (messageId == null || messageText == null) return "";

        String firstTwo = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord  = words.length > 1 ? words[words.length - 1] : firstWord;

        // Remove any non-letter characters for cleaner hash (still acceptable)
        firstWord = firstWord.replaceAll("[^a-zA-Z]", "");
        lastWord  = lastWord.replaceAll("[^a-zA-Z]", "");

        this.messageHash = (firstTwo + ":" + (numMessagesSent - 1) + ":" + firstWord + lastWord).toUpperCase();
        return this.messageHash;
    }

    /**
     * Allows the user to choose Send / Store / Disregard.
     * Returns the exact messages required by the brief.
     */
    public String SentMessage(int choice) {
        switch (choice) {
            case 1: // Send
                this.flag = "Sent";
                sentMessages.add(this);
                messageHashes.add(this.messageHash);
                messageIds.add(this.messageId);
                return "Message successfully sent.";
            case 2: // Disregard
                this.flag = "Disregard";
                disregardedMessages.add(this);
                return "Press 0 to delete the message.";
            case 3: // Store
                this.flag = "Stored";
                storedMessages.add(this);
                storeMessage();                 // also write to JSON
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    /**
     * Returns a printable summary of all messages sent during the run.
     */
    public String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageId)
              .append("\nMessage Hash: ").append(m.messageHash)
              .append("\nRecipient: ").append(m.recipient)
              .append("\nMessage: ").append(m.messageText)
              .append("\n-------------------------\n");
        }
        return sb.toString();
    }

    /**
     * Returns the total number of messages that were successfully sent.
     */
    public int returnTotalMessagess() {
        return sentMessages.size();
    }

    /**
     * Stores the current message into a simple JSON file (messages.json).
     * Research note: basic file I/O used; format is a JSON array of objects.
     */
    public void storeMessage() {
        try {
            // Build a simple JSON array string
            StringBuilder json = new StringBuilder("[\n");
            for (int i = 0; i < storedMessages.size(); i++) {
                Message m = storedMessages.get(i);
                json.append("  {\n")
                    .append("    \"messageId\": \"").append(m.messageId).append("\",\n")
                    .append("    \"messageHash\": \"").append(m.messageHash).append("\",\n")
                    .append("    \"recipient\": \"").append(m.recipient).append("\",\n")
                    .append("    \"message\": \"").append(escapeJson(m.messageText)).append("\",\n")
                    .append("    \"flag\": \"").append(m.flag).append("\"\n")
                    .append("  }");
                if (i < storedMessages.size() - 1) json.append(",");
                json.append("\n");
            }
            json.append("]");

            try (FileWriter writer = new FileWriter("messages.json")) {
                writer.write(json.toString());
            }
        } catch (IOException e) {
            System.out.println("Error writing JSON file: " + e.getMessage());
        }
    }

    // ---------- Helper / utility methods ----------

    private String generateMessageId() {
        // 10-digit random number as required
        Random rnd = new Random();
        long num = 1_000_000_000L + (long)(rnd.nextDouble() * 9_000_000_000L);
        return String.valueOf(num).substring(0, 10);
    }

    private String escapeJson(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    // Load stored messages back from the JSON file (simple parser for this level)
    public static void loadStoredMessagesFromJson() {
        try {
            if (!Files.exists(Paths.get("messages.json"))) return;
            // For this student-level project we keep the in-memory list as source of truth.
            // A full JSON parser would be added in a later module.
        } catch (Exception e) {
            System.out.println("Could not load messages.json");
        }
    }

    // ---------- Part 3 helper methods that work on the arrays ----------

    public static String displaySendersAndRecipients() {
        if (storedMessages.isEmpty()) return "No stored messages.";
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Recipient: ").append(m.recipient)
              .append(" | Message: ").append(m.messageText).append("\n");
        }
        return sb.toString();
    }

    public static String displayLongestMessage() {
        Message longest = null;
        // Check both sent and stored for the longest overall (brief focuses on stored)
        List<Message> combined = new ArrayList<>();
        combined.addAll(sentMessages);
        combined.addAll(storedMessages);

        for (Message m : combined) {
            if (longest == null || m.messageText.length() > longest.messageText.length()) {
                longest = m;
            }
        }
        return longest != null ? longest.messageText : "No messages found.";
    }

    public static String searchByMessageId(String id) {
        for (Message m : sentMessages) {
            if (m.messageId.equals(id)) {
                return "Recipient: " + m.recipient + "\nMessage: " + m.messageText;
            }
        }
        for (Message m : storedMessages) {
            if (m.messageId.equals(id)) {
                return "Recipient: " + m.recipient + "\nMessage: " + m.messageText;
            }
        }
        return "Message ID not found.";
    }

    public static String searchByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            if (m.recipient.equals(recipient)) {
                sb.append(m.messageText).append("\n");
            }
        }
        for (Message m : storedMessages) {
            if (m.recipient.equals(recipient)) {
                sb.append(m.messageText).append("\n");
            }
        }
        return sb.length() > 0 ? sb.toString() : "No messages found for that recipient.";
    }

    public static String deleteByHash(String hash) {
        // Remove from storedMessages (and the parallel lists)
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).messageHash.equals(hash)) {
                Message removed = storedMessages.remove(i);
                messageHashes.remove(hash);
                return "Message \"" + removed.messageText + "\" successfully deleted.";
            }
        }
        // Also allow deleting from sent if required
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).messageHash.equals(hash)) {
                Message removed = sentMessages.remove(i);
                messageHashes.remove(hash);
                return "Message \"" + removed.messageText + "\" successfully deleted.";
            }
        }
        return "Hash not found.";
    }

    public static String displayFullReport() {
        StringBuilder sb = new StringBuilder("===== FULL MESSAGE REPORT =====\n\n");
        sb.append("--- SENT MESSAGES ---\n");
        for (Message m : sentMessages) {
            sb.append("Hash: ").append(m.messageHash)
              .append("\nRecipient: ").append(m.recipient)
              .append("\nMessage: ").append(m.messageText)
              .append("\n\n");
        }
        sb.append("--- STORED MESSAGES ---\n");
        for (Message m : storedMessages) {
            sb.append("Hash: ").append(m.messageHash)
              .append("\nRecipient: ").append(m.recipient)
              .append("\nMessage: ").append(m.messageText)
              .append("\n\n");
        }
        return sb.toString();
    }

    // ---------- Getters ----------
    public String getMessageId()    { return messageId; }
    public String getMessageHash()  { return messageHash; }
    public String getRecipient()    { return recipient; }
    public String getMessageText()  { return messageText; }
    public String getFlag()         { return flag; }
    public int getNumMessagesSent() { return numMessagesSent; }

    // Static getters for the arrays (useful for unit tests)
    public static List<Message> getSentMessages()        { return sentMessages; }
    public static List<Message> getDisregardedMessages() { return disregardedMessages; }
    public static List<Message> getStoredMessages()      { return storedMessages; }
    public static List<String>  getMessageHashes()       { return messageHashes; }
    public static List<String>  getMessageIds()          { return messageIds; }
}
