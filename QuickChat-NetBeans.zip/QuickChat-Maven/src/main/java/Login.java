/**
 * Login class - Part 1 of the PoE
 * Contains all required validation and authentication methods.
 * Console-only application (no GUI).
 */
public class Login {

    // Stored registration details (simple in-memory storage for this level)
    private String storedUsername;
    private String storedPassword;
    private String firstName;
    private String lastName;
    private String cellPhone;

    // ---------- Required Boolean check methods ----------

    /**
     * Username must contain an underscore and be no more than 5 characters long.
     */
    public boolean checkUserName(String username) {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    /**
     * Password complexity rules:
     * - At least 8 characters
     * - At least one capital letter
     * - At least one number
     * - At least one special character
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            else if (Character.isDigit(c)) hasNumber = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    /**
     * Cell phone must start with international code (+27) and the number part
     * must be no more than 10 characters. Test data examples use +27 followed by 9 digits.
     * Regex attributed from common South African mobile validation patterns.
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        if (cellPhoneNumber == null) return false;
        // +27 followed by exactly 9 digits (total length 12) - matches the provided test data
        return cellPhoneNumber.matches("^\\+27\\d{9}$");
    }

    // ---------- Required String methods ----------

    /**
     * Registers the user and returns the appropriate message.
     * Stores the details only when all three validations pass.
     */
    public String registerUser(String username, String password, String cellPhone,
                               String firstName, String lastName) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellPhone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // All checks passed - store the details
        this.storedUsername = username;
        this.storedPassword = password;
        this.cellPhone = cellPhone;
        this.firstName = firstName;
        this.lastName = lastName;

        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser registered successfully.";
    }

    /**
     * Verifies that the entered credentials match the stored ones.
     */
    public boolean loginUser(String username, String password) {
        if (storedUsername == null || storedPassword == null) {
            return false;
        }
        return storedUsername.equals(username) && storedPassword.equals(password);
    }

    /**
     * Returns the login status message.
     */
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    // Convenience getters used by the main application
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }
    public String getCellPhone() { return cellPhone; }
    public boolean isRegistered() { return storedUsername != null; }
}
